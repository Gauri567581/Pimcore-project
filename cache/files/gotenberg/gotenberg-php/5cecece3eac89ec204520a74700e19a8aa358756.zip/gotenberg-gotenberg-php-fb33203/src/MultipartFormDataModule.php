<?php

declare(strict_types=1);

namespace Gotenberg;

use Gotenberg\Exceptions\NativeFunctionErrored;
use GuzzleHttp\Psr7\MultipartStream;
use Http\Discovery\Psr17FactoryDiscovery;
use Psr\Http\Message\RequestInterface;
use Psr\Http\Message\StreamInterface;

use function count;
use function json_encode;

trait MultipartFormDataModule
{
    use ApiModule;

    /** @var array<array<string,mixed>> */
    private array $multipartFormData = [];

    /**
     * Overrides the default UUID output filename.
     * Note: Gotenberg adds the file extension automatically; you don't have to
     * set it.
     */
    public function outputFilename(string $filename): self
    {
        $this->headers['Gotenberg-Output-Filename'] = $filename;

        return $this;
    }

    /**
     * Sets the URLs to download files from.
     *
     * @param DownloadFrom[] $downloadFrom
     *
     * @throws NativeFunctionErrored
     */
    public function downloadFrom(array $downloadFrom): self
    {
        $json = json_encode($downloadFrom);
        if ($json === false) {
            throw NativeFunctionErrored::createFromLastPhpError();
        }

        $this->formValue('downloadFrom', $json);

        return $this;
    }

    /**
     * Sets the callback and error callback that Gotenberg will use to send
     * respectively the output file and the error response.
     *
     * @param string $errorUrl Deprecated: use webhookEventsUrl() instead.
     *                         If Gotenberg-Webhook-Events-Url is set, this
     *                         parameter is not required.
     */
    public function webhook(string $url, string $errorUrl = ''): self
    {
        $this->headers['Gotenberg-Webhook-Url'] = $url;

        if ($errorUrl !== '') {
            $this->headers['Gotenberg-Webhook-Error-Url'] = $errorUrl;
        }

        return $this;
    }

    /**
     * Overrides the default HTTP method that Gotenberg will use to call the
     * webhook.
     *
     * Either "POST", "PATCH", or "PUT" - default "POST".
     */
    public function webhookMethod(string $method): self
    {
        $this->headers['Gotenberg-Webhook-Method'] = $method;

        return $this;
    }

    /**
     * Overrides the default HTTP method that Gotenberg will use to call the
     * error webhook.
     *
     * Either "POST", "PATCH", or "PUT" - default "POST".
     *
     * @deprecated Use webhookEventsUrl() instead.
     */
    public function webhookErrorMethod(string $method): self
    {
        $this->headers['Gotenberg-Webhook-Error-Method'] = $method;

        return $this;
    }

    /**
     * Sets the extra HTTP headers that Gotenberg will send alongside the
     * request to the webhook and error webhook.
     *
     * @param array<string,string> $headers
     *
     * @throws NativeFunctionErrored
     */
    public function webhookExtraHttpHeaders(array $headers): self
    {
        $json = json_encode($headers);
        if ($json === false) {
            throw NativeFunctionErrored::createFromLastPhpError();
        }

        $this->headers['Gotenberg-Webhook-Extra-Http-Headers'] = $json;

        return $this;
    }

    /**
     * Sets the URL that Gotenberg will use to send webhook event
     * notifications (e.g., success/error events after webhook delivery).
     */
    public function webhookEventsUrl(string $url): self
    {
        $this->headers['Gotenberg-Webhook-Events-Url'] = $url;

        return $this;
    }

    /**
     * Configures watermarking on the resulting PDF(s).
     * Only non-empty values are set.
     *
     * @param array<string,mixed> $options
     *
     * @throws NativeFunctionErrored
     */
    public function watermarking(string $source, string $expression = '', string $pages = '', array $options = []): self
    {
        $this->formValue('watermarkSource', $source);

        if ($expression !== '') {
            $this->formValue('watermarkExpression', $expression);
        }

        if ($pages !== '') {
            $this->formValue('watermarkPages', $pages);
        }

        if (count($options) > 0) {
            $json = json_encode($options);
            if ($json === false) {
                throw NativeFunctionErrored::createFromLastPhpError();
            }

            $this->formValue('watermarkOptions', $json);
        }

        return $this;
    }

    /**
     * Adds watermark file.
     */
    public function watermarkFile(Stream $file): self
    {
        $this->formFile($file->getFilename(), $file->getStream(), 'watermark');

        return $this;
    }

    /**
     * Configures stamping on the resulting PDF(s).
     * Only non-empty values are set.
     *
     * @param array<string,mixed> $options
     *
     * @throws NativeFunctionErrored
     */
    public function stamping(string $source, string $expression = '', string $pages = '', array $options = []): self
    {
        $this->formValue('stampSource', $source);

        if ($expression !== '') {
            $this->formValue('stampExpression', $expression);
        }

        if ($pages !== '') {
            $this->formValue('stampPages', $pages);
        }

        if (count($options) > 0) {
            $json = json_encode($options);
            if ($json === false) {
                throw NativeFunctionErrored::createFromLastPhpError();
            }

            $this->formValue('stampOptions', $json);
        }

        return $this;
    }

    /**
     * Adds stamp file.
     */
    public function stampFile(Stream $file): self
    {
        $this->formFile($file->getFilename(), $file->getStream(), 'stamp');

        return $this;
    }

    /**
     * Configures rotation on the resulting PDF(s).
     * Only non-empty values are set.
     */
    public function rotating(int $angle, string $pages = ''): self
    {
        $this->formValue('rotateAngle', $angle);

        if ($pages !== '') {
            $this->formValue('rotatePages', $pages);
        }

        return $this;
    }

    protected function formValue(string $name, mixed $value): self
    {
        $this->multipartFormData[] = [
            'name' => $name,
            'contents' => $value,
        ];

        return $this;
    }

    protected function formFile(string $filename, StreamInterface $stream, string $name = 'files'): void
    {
        $this->multipartFormData[] = [
            'name' => $name,
            'filename' => $filename,
            'contents' => $stream,
        ];
    }

    protected function request(string $method = 'POST'): RequestInterface
    {
        $body = new MultipartStream($this->multipartFormData);

        $request = Psr17FactoryDiscovery::findRequestFactory()
            ->createRequest($method, $this->url . $this->endpoint)
            ->withHeader('Content-Type', 'multipart/form-data; boundary="' . $body->getBoundary() . '"')
            ->withBody($body);

        foreach ($this->headers as $key => $value) {
            $request = $request->withHeader($key, $value);
        }

        return $request;
    }
}
