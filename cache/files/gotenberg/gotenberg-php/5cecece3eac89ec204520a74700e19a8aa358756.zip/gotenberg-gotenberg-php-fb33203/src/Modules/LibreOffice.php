<?php

declare(strict_types=1);

namespace Gotenberg\Modules;

use Gotenberg\EmbedMetadata;
use Gotenberg\Exceptions\NativeFunctionErrored;
use Gotenberg\FacturX;
use Gotenberg\HrtimeIndex;
use Gotenberg\Index;
use Gotenberg\MultipartFormDataModule;
use Gotenberg\SplitMode;
use Gotenberg\Stream;
use Psr\Http\Message\RequestInterface;

use function json_encode;

class LibreOffice
{
    use MultipartFormDataModule;

    private Index|null $index = null;
    private bool $merge       = false;

    /**
     * Overrides the default index generator for ordering
     * files we want to merge.
     */
    public function index(Index $index): self
    {
        $this->index = $index;

        return $this;
    }

    /**
     * Sets the password for opening the source file.
     */
    public function password(string $password): self
    {
        $this->formValue('password', $password);

        return $this;
    }

    /**
     * Sets the paper orientation to landscape.
     */
    public function landscape(): self
    {
        $this->formValue('landscape', true);

        return $this;
    }

    /**
     * Sets the page ranges to print, e.g., "1-4"'.
     * Empty means all pages.
     *
     * Note: the page ranges are applied to all files independently.
     */
    public function nativePageRanges(string $ranges): self
    {
        $this->formValue('nativePageRanges', $ranges);

        return $this;
    }

    /**
     * Specifies whether to update the indexes before conversion, keeping in
     * mind that doing so might result in missing links in the final PDF.
     */
    public function updateIndexes(bool $update = true): self
    {
        $this->formValue('updateIndexes', $update ?: '0');

        return $this;
    }

    /**
     * Specifies whether form fields are exported as widgets or only their fixed
     * print representation is exported.
     */
    public function exportFormFields(bool $export = true): self
    {
        $this->formValue('exportFormFields', $export ?: '0');

        return $this;
    }

    /**
     * Specifies whether multiple form fields exported are allowed to have the
     * same field name.
     */
    public function allowDuplicateFieldNames(): self
    {
        $this->formValue('allowDuplicateFieldNames', true);

        return $this;
    }

    /**
     * Specifies if bookmarks are exported to PDF.
     */
    public function exportBookmarks(bool $export = true): self
    {
        $this->formValue('exportBookmarks', $export ?: '0');

        return $this;
    }

    /**
     * Specifies that the bookmarks contained in the source LibreOffice file
     * should be exported to the PDF file as Named Destination.
     */
    public function exportBookmarksToPdfDestination(): self
    {
        $this->formValue('exportBookmarksToPdfDestination', true);

        return $this;
    }

    /**
     * Exports the placeholders fields visual markings only. The exported
     * placeholder is ineffective.
     */
    public function exportPlaceholders(): self
    {
        $this->formValue('exportPlaceholders', true);

        return $this;
    }

    /**
     * Specifies if notes are exported to PDF.
     */
    public function exportNotes(): self
    {
        $this->formValue('exportNotes', true);

        return $this;
    }

    /**
     * Specifies if notes pages are exported to PDF. Notes pages are available
     * in Impress documents only.
     */
    public function exportNotesPages(): self
    {
        $this->formValue('exportNotesPages', true);

        return $this;
    }

    /**
     * Specifies, if the form field exportNotesPages is set to true, if only
     * notes pages are exported to PDF.
     */
    public function exportOnlyNotesPages(): self
    {
        $this->formValue('exportOnlyNotesPages', true);

        return $this;
    }

    /**
     * Specifies if notes in margin are exported to PDF.
     */
    public function exportNotesInMargin(): self
    {
        $this->formValue('exportNotesInMargin', true);

        return $this;
    }

    /**
     * Specifies that the target documents with .od[tpgs] extension, will have
     * that extension changed to .pdf when the link is exported to PDF. The
     * source document remains untouched.
     */
    public function convertOooTargetToPdfTarget(): self
    {
        $this->formValue('convertOooTargetToPdfTarget', true);

        return $this;
    }

    /**
     * Specifies that the file system related hyperlinks (file:// protocol)
     * present in the document will be exported as relative to the source
     * document location.
     */
    public function exportLinksRelativeFsys(): self
    {
        $this->formValue('exportLinksRelativeFsys', true);

        return $this;
    }

    /**
     * Exports, for LibreOffice Impress, slides that are not included in slide
     * shows.
     */
    public function exportHiddenSlides(): self
    {
        $this->formValue('exportHiddenSlides', true);

        return $this;
    }

    /**
     * Specifies that automatically inserted empty pages are suppressed. This
     * option is active only if storing Writer documents.
     */
    public function skipEmptyPages(): self
    {
        $this->formValue('skipEmptyPages', true);

        return $this;
    }

    /**
     * Specifies that a stream is inserted to the PDF file which contains the
     * original document for archiving purposes.
     */
    public function addOriginalDocumentAsStream(): self
    {
        $this->formValue('addOriginalDocumentAsStream', true);

        return $this;
    }

    /**
     * Specifies how the document shall be displayed when opened. Possible
     * values are: "document", "outline", "thumbnails".
     */
    public function initialView(string $view): self
    {
        $this->formValue('initialView', $view);

        return $this;
    }

    /**
     * Specifies the page on which a PDF document should be opened in the
     * viewer.
     */
    public function initialPage(int $page): self
    {
        $this->formValue('initialPage', $page);

        return $this;
    }

    /**
     * Specifies the magnification to use when the document is opened.
     * Possible values are: "default", "fitVisible", "fitWidth", "fitPage",
     * "fitActualSize".
     */
    public function magnification(string $magnification): self
    {
        $this->formValue('magnification', $magnification);

        return $this;
    }

    /**
     * Specifies the zoom value to use when the document is opened.
     */
    public function zoom(int $zoom): self
    {
        $this->formValue('zoom', $zoom);

        return $this;
    }

    /**
     * Specifies the page layout to use when the document is opened. Possible
     * values are: "default", "singlePage", "continuous", "continuousFacing".
     */
    public function pageLayout(string $layout): self
    {
        $this->formValue('pageLayout', $layout);

        return $this;
    }

    /**
     * Specifies that the first page on the left side of the viewer should be
     * displayed in a two-column layout.
     */
    public function firstPageOnLeft(): self
    {
        $this->formValue('firstPageOnLeft', true);

        return $this;
    }

    /**
     * Specifies that the PDF viewer window should be resized to fit the size
     * of the first page of the document.
     */
    public function resizeWindowToInitialPage(): self
    {
        $this->formValue('resizeWindowToInitialPage', true);

        return $this;
    }

    /**
     * Specifies that the PDF viewer window should be centered on the screen.
     */
    public function centerWindow(): self
    {
        $this->formValue('centerWindow', true);

        return $this;
    }

    /**
     * Specifies that the PDF document should be displayed in full-screen mode.
     */
    public function openInFullScreenMode(): self
    {
        $this->formValue('openInFullScreenMode', true);

        return $this;
    }

    /**
     * Specifies that the title of the document should be displayed in the
     * title bar of the viewer.
     */
    public function displayPDFDocumentTitle(): self
    {
        $this->formValue('displayPDFDocumentTitle', true);

        return $this;
    }

    /**
     * Specifies that the viewer's menu bar should be hidden.
     */
    public function hideViewerMenubar(): self
    {
        $this->formValue('hideViewerMenubar', true);

        return $this;
    }

    /**
     * Specifies that the viewer's toolbar should be hidden.
     */
    public function hideViewerToolbar(): self
    {
        $this->formValue('hideViewerToolbar', true);

        return $this;
    }

    /**
     * Specifies that the viewer's window controls should be hidden.
     */
    public function hideViewerWindowControls(): self
    {
        $this->formValue('hideViewerWindowControls', true);

        return $this;
    }

    /**
     * Specifies whether to use transition effects when displaying the
     * document.
     */
    public function useTransitionEffects(): self
    {
        $this->formValue('useTransitionEffects', true);

        return $this;
    }

    /**
     * Specifies the number of bookmark levels to display in the viewer when
     * the document is opened.
     */
    public function openBookmarkLevels(int $levels): self
    {
        $this->formValue('openBookmarkLevels', $levels);

        return $this;
    }

    /**
     * Ignores each sheet's paper size, print ranges and shown/hidden status
     * and puts every sheet (even hidden sheets) on exactly one page.
     */
    public function singlePageSheets(): self
    {
        $this->formValue('singlePageSheets', true);

        return $this;
    }

    /**
     * Specifies if images are exported to PDF using a lossless compression
     * format like PNG or compressed using the JPEG format.
     */
    public function losslessImageCompression(): self
    {
        $this->formValue('losslessImageCompression', true);

        return $this;
    }

    /**
     * Specifies the quality of the JPG export. A higher value produces a
     * higher-quality image and a larger file. Between 1 and 100.
     */
    public function quality(int $quality): self
    {
        $this->formValue('quality', $quality);

        return $this;
    }

    /**
     * Specifies if the resolution of each image is reduced to the resolution
     * specified by the form field maxImageResolution.
     * FIXME: parameter not used.
     */
    public function reduceImageResolution(bool $notUsedAnymore = true): self
    {
        $this->formValue('reduceImageResolution', true);

        return $this;
    }

    /**
     * If the form field reduceImageResolution is set to true, tells if all
     * images will be reduced to the given value in DPI. Possible values are:
     * 75, 150, 300, 600 and 1200.
     */
    public function maxImageResolution(int $dpi): self
    {
        $this->formValue('maxImageResolution', $dpi);

        return $this;
    }

    /**
     * Sets the native watermark text.
     */
    public function nativeWatermarkText(string $text): self
    {
        $this->formValue('nativeWatermarkText', $text);

        return $this;
    }

    /**
     * Sets the native watermark color.
     */
    public function nativeWatermarkColor(int $color): self
    {
        $this->formValue('nativeWatermarkColor', $color);

        return $this;
    }

    /**
     * Sets the native watermark font height.
     */
    public function nativeWatermarkFontHeight(int $height): self
    {
        $this->formValue('nativeWatermarkFontHeight', $height);

        return $this;
    }

    /**
     * Sets the native watermark rotate angle.
     */
    public function nativeWatermarkRotateAngle(int $angle): self
    {
        $this->formValue('nativeWatermarkRotateAngle', $angle);

        return $this;
    }

    /**
     * Sets the native watermark font name.
     */
    public function nativeWatermarkFontName(string $name): self
    {
        $this->formValue('nativeWatermarkFontName', $name);

        return $this;
    }

    /**
     * Sets the native tiled watermark text.
     */
    public function nativeTiledWatermarkText(string $text): self
    {
        $this->formValue('nativeTiledWatermarkText', $text);

        return $this;
    }

    /**
     * Sets the PDF/A format of the resulting PDF.
     */
    public function pdfa(string $format): self
    {
        $this->formValue('pdfa', $format);

        return $this;
    }

    /**
     * Enables PDF for Universal Access for optimal accessibility.
     */
    public function pdfua(): self
    {
        $this->formValue('pdfua', true);

        return $this;
    }

    /**
     * Sets the metadata to write.
     *
     * @param array<string,string|bool|float|int|array<string>> $metadata
     *
     * @throws NativeFunctionErrored
     */
    public function metadata(array $metadata): self
    {
        $json = json_encode($metadata);
        if ($json === false) {
            throw NativeFunctionErrored::createFromLastPhpError();
        }

        $this->formValue('metadata', $json);

        return $this;
    }

    /**
     * Merges the resulting PDFs.
     */
    public function merge(): self
    {
        $this->merge = true;
        $this->formValue('merge', true);

        return $this;
    }

    /**
     * Splits the resulting PDFs.
     */
    public function split(SplitMode $mode): self
    {
        $this->formValue('splitMode', $mode->mode);
        $this->formValue('splitSpan', $mode->span);
        $this->formValue('splitUnify', $mode->unify ?: '0');

        return $this;
    }

    /**
     * Defines whether the resulting PDF should be flattened.
     */
    public function flatten(): self
    {
        $this->formValue('flatten', true);

        return $this;
    }

    /**
     * Defines whether the resulting PDF should be encrypted.
     */
    public function encrypt(string $userPassword, string $ownerPassword = ''): self
    {
        $this->formValue('userPassword', $userPassword);
        $this->formValue('ownerPassword', $ownerPassword);

        return $this;
    }

    /**
     * Specifies whether printing the resulting PDF is allowed.
     * Note: restricting any permission requires a userPassword or ownerPassword.
     */
    public function allowPrinting(bool $allow = true): self
    {
        $this->formValue('allowPrinting', $allow ?: '0');

        return $this;
    }

    /**
     * Specifies whether copying text and graphics from the resulting PDF is
     * allowed.
     * Note: restricting any permission requires a userPassword or ownerPassword.
     */
    public function allowCopying(bool $allow = true): self
    {
        $this->formValue('allowCopying', $allow ?: '0');

        return $this;
    }

    /**
     * Specifies whether modifying the resulting PDF is allowed.
     * Note: restricting any permission requires a userPassword or ownerPassword.
     */
    public function allowModifying(bool $allow = true): self
    {
        $this->formValue('allowModifying', $allow ?: '0');

        return $this;
    }

    /**
     * Specifies whether adding or modifying annotations in the resulting PDF is
     * allowed.
     * Note: restricting any permission requires a userPassword or ownerPassword.
     */
    public function allowAnnotating(bool $allow = true): self
    {
        $this->formValue('allowAnnotating', $allow ?: '0');

        return $this;
    }

    /**
     * Specifies whether filling interactive form fields in the resulting PDF is
     * allowed.
     * Note: restricting any permission requires a userPassword or ownerPassword.
     */
    public function allowFillingForms(bool $allow = true): self
    {
        $this->formValue('allowFillingForms', $allow ?: '0');

        return $this;
    }

    /**
     * Specifies whether assembling the resulting PDF (insert, rotate, or delete
     * pages and create bookmarks or thumbnails) is allowed.
     * Note: restricting any permission requires a userPassword or ownerPassword.
     */
    public function allowAssembling(bool $allow = true): self
    {
        $this->formValue('allowAssembling', $allow ?: '0');

        return $this;
    }

    /**
     * Configures the embedding of a Factur-X / ZUGFeRD invoice XML into the
     * resulting PDF. Requires a PDF/A-3 variant (set via the pdfa method).
     */
    public function facturX(FacturX $facturx): self
    {
        $this->formFile($facturx->xml->getFilename(), $facturx->xml->getStream(), 'facturxXml');
        $this->formValue('facturxConformanceLevel', $facturx->conformanceLevel);
        $this->formValue('facturxDocumentType', $facturx->documentType);
        $this->formValue('facturxVersion', $facturx->version);

        return $this;
    }

    /**
     * Sets the file to embed in the resulting PDF.
     */
    public function embeds(Stream ...$embeds): self
    {
        foreach ($embeds as $embed) {
            $this->formFile($embed->getFilename(), $embed->getStream(), 'embeds');
        }

        return $this;
    }

    /**
     * Sets metadata on embedded files in the resulting PDF, required for
     * Factur-X / ZUGFeRD compliance.
     *
     * @throws NativeFunctionErrored
     */
    public function embedsMetadata(EmbedMetadata ...$metadata): self
    {
        $map = [];
        foreach ($metadata as $entry) {
            $map[$entry->filename] = $entry;
        }

        $json = json_encode($map);
        if ($json === false) {
            throw NativeFunctionErrored::createFromLastPhpError();
        }

        $this->formValue('embedsMetadata', $json);

        return $this;
    }

    /**
     * Converts the given document(s) to PDF(s). Gotenberg will return either
     * a unique PDF if you request a merge or a ZIP archive with the PDFs.
     *
     * Note: if you requested a merge, the merging order is determined by the
     * order of the arguments.
     */
    public function convert(Stream ...$files): RequestInterface
    {
        $index = $this->index ?? new HrtimeIndex();
        foreach ($files as $file) {
            $filename = $this->merge ? $index->create() . '_' . $file->getFilename() : $file->getFilename();
            $this->formFile($filename, $file->getStream());
        }

        $this->endpoint = '/forms/libreoffice/convert';

        return $this->request();
    }
}
