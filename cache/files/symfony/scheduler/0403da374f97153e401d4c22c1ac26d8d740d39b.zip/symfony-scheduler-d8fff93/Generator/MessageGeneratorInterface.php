<?php

/*
 * This file is part of the Symfony package.
 *
 * (c) Fabien Potencier <fabien@symfony.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Symfony\Component\Scheduler\Generator;

interface MessageGeneratorInterface
{
    /**
     * @return iterable<MessageContext, object>
     */
    public function getMessages(): iterable;
}
