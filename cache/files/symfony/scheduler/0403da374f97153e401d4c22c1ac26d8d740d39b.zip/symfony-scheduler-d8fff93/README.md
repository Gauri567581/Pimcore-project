Scheduler Component
===================

Provides scheduling through Symfony Messenger.

Resources
---------

 * [Documentation](https://symfony.com/doc/current/scheduler.html)
 * [Contributing](https://symfony.com/doc/current/contributing/index.html)
 * [Report issues](https://github.com/symfony/symfony/issues) and
   [send Pull Requests](https://github.com/symfony/symfony/pulls)
   in the [main Symfony repository](https://github.com/symfony/symfony)
