<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\GenericDataIndexBundle\SearchIndexAdapter\DefaultSearch\DataObject\FieldDefinitionAdapter;

use Exception;
use InvalidArgumentException;
use Pimcore\Bundle\StaticResolverBundle\Models\DataObject\Objectbrick\DefinitionResolverInterface;
use Pimcore\Model\DataObject\ClassDefinition\Data;
use Pimcore\Model\DataObject\ClassDefinition\Data\Objectbricks;
use Pimcore\Model\DataObject\Concrete;
use Pimcore\Model\DataObject\Objectbrick;
use Pimcore\Model\DataObject\Objectbrick\Data\AbstractData;
use Symfony\Contracts\Service\Attribute\Required;

/**
 * @internal
 */
final class ObjectBrickAdapter extends AbstractAdapter
{
    private DefinitionResolverInterface $objectBrickDefinition;

    #[Required]
    public function setObjectBrickDefinition(DefinitionResolverInterface $definitionResolver): void
    {
        $this->objectBrickDefinition = $definitionResolver;
    }

    public function getIndexMapping(): array
    {
        $objectBricks = $this->getFieldDefinition();
        $mapping = [];
        if (!$objectBricks instanceof Objectbricks) {
            throw new InvalidArgumentException(
                'FieldDefinition must be of type Data\Objectbricks'
            );
        }

        foreach ($objectBricks->getAllowedTypes() as $type) {
            $mapping[$type]['properties'] = $this->getMappingForObjectBrick($type);
        }

        return [
            'properties' => $mapping,
        ];
    }

    public function normalize(mixed $value): ?array
    {
        if (!$value instanceof Objectbrick) {
            return null;
        }

        $resultItems = [];
        $items = $value->getObjectVars();
        foreach ($items as $item) {
            if (!$item instanceof AbstractData) {
                continue;
            }

            $type = $item->getType();
            $resultItems[$type] = [];
            $definition = $this->objectBrickDefinition->getByKey($type);
            if ($definition === null) {
                continue;
            }

            foreach ($definition->getFieldDefinitions() as $fieldDefinition) {
                $getter = 'get' . ucfirst($fieldDefinition->getName());
                $value = $item->$getter();
                $resultItems[$type][$fieldDefinition->getName()] = $this->fieldDefinitionService->normalizeValue(
                    $fieldDefinition,
                    $value
                );
            }
        }

        return $resultItems;
    }

    public function getInheritedData(
        Concrete $dataObject,
        int $objectId,
        mixed $value,
        string $key,
        ?string $language = null,
        ?callable $callback = null
    ): array {
        if (!$value instanceof Objectbrick) {
            return [];
        }
        $result = [];
        foreach ($value->getAllowedBrickTypes() as $type) {
            $brickGetter = 'get' . $type;
            $brick = $value->$brickGetter();
            if (!$brick) {
                continue;
            }

            $fieldDefinitions = Objectbrick\Definition::getByKey($type)?->getFieldDefinitions();
            foreach ($fieldDefinitions as $fieldDefinition) {
                $data = $this->getInheritedDataForFieldDefinition(
                    $dataObject,
                    $fieldDefinition,
                    $brick,
                    $brickGetter,
                    $key,
                    $type
                );

                foreach ($data as $itemKey => $item) {
                    $path = $key . '.' . $type . '.' . ($itemKey !== $key ? $itemKey : $fieldDefinition->getName());
                    $result[$path] = $item;
                }
            }
        }

        return $result;
    }

    /**
     * @throws Exception
     */
    private function getInheritedDataForFieldDefinition(
        Concrete $dataObject,
        Data $fieldDefinition,
        AbstractData $brick,
        string $brickGetter,
        string $key,
        string $type
    ): array {
        $adapter = $this->getFieldDefinitionService()->getFieldDefinitionAdapter($fieldDefinition);
        if (!$adapter) {
            return [];
        }

        $fieldGetter = 'get' . ucfirst($fieldDefinition->getName());
        if ($adapter instanceof LocalizedFieldsAdapter) {
            return $adapter->getInheritedDataForBrick(
                $dataObject,
                $brick->$fieldGetter(),
                $key,
                $type
            );
        }

        return $adapter->getInheritedData(
            $dataObject,
            $dataObject->getId(),
            $brick->$fieldGetter(),
            $key,
            null,
            static fn (
                Concrete $parent, string $key, ?string $language
            ) => $parent->get($key)->$brickGetter()?->$fieldGetter($language)
        );
    }

    private function getMappingForObjectBrick(string $objectBrickType): array
    {
        $fieldDefinitions = $this->objectBrickDefinition->getByKey($objectBrickType)?->getFieldDefinitions();
        $mapping = [];
        foreach ($fieldDefinitions as $fieldDefinition) {
            $adapter = $this->getFieldDefinitionService()->getFieldDefinitionAdapter($fieldDefinition);
            if ($adapter) {
                $mapping[$adapter->getIndexAttributeName()] = $adapter->getIndexMapping();
            }
        }

        return $mapping;
    }
}
