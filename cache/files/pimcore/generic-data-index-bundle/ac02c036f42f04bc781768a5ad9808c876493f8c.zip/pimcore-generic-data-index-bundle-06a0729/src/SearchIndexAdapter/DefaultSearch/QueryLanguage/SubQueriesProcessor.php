<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\GenericDataIndexBundle\SearchIndexAdapter\DefaultSearch\QueryLanguage;

use Pimcore\Bundle\GenericDataIndexBundle\Enum\SearchIndex\DefaultSearch\ConditionType;
use Pimcore\Bundle\GenericDataIndexBundle\Exception\QueryLanguage\ParsingException;
use Pimcore\Bundle\GenericDataIndexBundle\Model\DefaultSearch\Query\BoolQuery;
use Pimcore\Bundle\GenericDataIndexBundle\Model\DefaultSearch\Search;
use Pimcore\Bundle\GenericDataIndexBundle\Model\QueryLanguage\SubQueryResultList;
use Pimcore\Bundle\GenericDataIndexBundle\QueryLanguage\ProcessorInterface;
use Pimcore\Bundle\GenericDataIndexBundle\SearchIndexAdapter\DefaultSearch\Search\FetchIdsBySearchServiceInterface;
use Pimcore\Bundle\GenericDataIndexBundle\SearchIndexAdapter\SearchIndexServiceInterface;
use Pimcore\Bundle\GenericDataIndexBundle\Service\SearchIndex\IndexEntityServiceInterface;

/**
 * @internal
 */
final readonly class SubQueriesProcessor implements SubQueriesProcessorInterface
{
    public function __construct(
        private IndexEntityServiceInterface $indexEntityService,
        private SearchIndexServiceInterface $searchIndexService,
        private FetchIdsBySearchServiceInterface $fetchIdsBySearchService,
    ) {

    }

    public function processSubQueries(
        ProcessorInterface $processor,
        string $originalQuery,
        array $subQueries
    ): SubQueryResultList {
        $list = new SubQueryResultList();
        foreach ($subQueries as $subQuery) {

            $indexEntity = $this->indexEntityService->getByEntityName($subQuery->getTargetType());

            if (!$this->searchIndexService->existsAlias($indexEntity->getIndexName())) {
                throw new ParsingException(
                    $originalQuery,
                    'a valid entity name',
                    '`' . $subQuery->getTargetType(). '`',
                    null,
                    null,
                    $subQuery->getPositionInOriginalQuery() - strlen($subQuery->getTargetType()) - 1,
                );
            }

            try {
                $query = $processor->process(
                    $subQuery->getTargetQuery(),
                    $indexEntity,
                );
            } catch (ParsingException $e) {
                throw new ParsingException(
                    $originalQuery,
                    $e->getExpected(),
                    $e->getFound(),
                    $e->getToken(),
                    $e->getMessage(),
                    $subQuery->getPositionInOriginalQuery() + $e->getPosition(),
                    $e
                );
            }

            $search = new Search();
            $search
                ->addQuery(new BoolQuery([ConditionType::FILTER->value => $query]));

            $list->addResult(
                $subQuery->getSubQueryId(),
                $this->fetchIdsBySearchService->fetchAllIds(
                    $search,
                    $indexEntity->getIndexName()
                )
            );
        }

        return $list;
    }
}
