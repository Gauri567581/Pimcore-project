<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\GenericDataIndexBundle\Service\SearchIndex;

use Pimcore\Bundle\GenericDataIndexBundle\SearchIndexAdapter\DefaultSearch\DefaultSearchService;
use Psr\Log\LoggerAwareTrait;

/**
 * @internal
 */
final class SearchIndexConfigService implements SearchIndexConfigServiceInterface
{
    use LoggerAwareTrait;

    private const SYSTEM_FIELD_GENERAL = 'general';

    public const SYSTEM_FIELD_ASSET = 'asset';

    public const SYSTEM_FIELD_DOCUMENT = 'document';

    public const SYSTEM_FIELD_DATA_OBJECT = 'data_object';

    public const CLASS_INDEX_PREFIX = 'data-object_';

    public function __construct(
        private readonly string $clientType,
        private readonly string $indexPrefix,
        private readonly array $indexSettings,
        private readonly array $searchSettings,
        private readonly array $systemFieldsSettings,
    ) {
    }

    public function getClientType(): string
    {
        return $this->clientType;
    }

    /**
     * returns index name for given class name
     */
    public function getIndexName(string $name, bool $isClass = false): string
    {
        if ($isClass) {
            return $this->getIndexPrefix() . self::CLASS_INDEX_PREFIX . strtolower($name);
        }

        return $this->getIndexPrefix() . strtolower($name);
    }

    /**
     * return index name without any prefix or suffix
     */
    public function getShortIndexName(string $name): string
    {
        if (str_starts_with($name, $this->getIndexPrefixWIthClassPrefix())) {
            $name = substr($name, 0, strlen($this->getIndexPrefixWIthClassPrefix()));
        }

        if (str_starts_with($name, $this->getIndexPrefix())) {
            $name = substr($name, 0, strlen($this->getIndexPrefix()));
        }

        if (str_ends_with($name, '-' . DefaultSearchService::INDEX_VERSION_ODD)) {
            $name = substr($name, strlen('-' . DefaultSearchService::INDEX_VERSION_ODD));
        }

        if (str_ends_with($name, '-' . DefaultSearchService::INDEX_VERSION_EVEN)) {
            $name = substr($name, strlen('-' . DefaultSearchService::INDEX_VERSION_EVEN));
        }

        return $name;
    }

    public function prefixIndexName(string $indexName): string
    {
        return $this->getIndexPrefix() . $indexName;
    }

    public function getIndexPrefix(): string
    {
        return $this->indexPrefix;
    }

    public function getIndexSettings(): array
    {
        return $this->indexSettings;
    }

    public function getSearchSettings(): array
    {
        return $this->searchSettings;
    }

    public function getSearchAnalyzerAttributes(): array
    {
        return $this->searchSettings['search_analyzer_attributes'] ?? [];
    }

    public function getMaxSynchronousChildrenRenameLimit(): int
    {
        return $this->searchSettings['max_synchronous_children_rename_limit'] ?? 0;
    }

    public function getSystemFieldsSettings(string $elementType): array
    {
        $systemFieldsSettings = array_merge(
            $this->systemFieldsSettings[self::SYSTEM_FIELD_GENERAL],
            $this->systemFieldsSettings[$elementType] ?? []
        );

        foreach ($systemFieldsSettings as &$systemFieldsSetting) {
            if (!count($systemFieldsSetting['properties'])) {
                unset($systemFieldsSetting['properties']);
            }
            if (!count($systemFieldsSetting['fields'])) {
                unset($systemFieldsSetting['fields']);
            }
        }

        return $systemFieldsSettings;
    }

    private function getIndexPrefixWIthClassPrefix(): string
    {
        return $this->indexPrefix . self::CLASS_INDEX_PREFIX;
    }
}
