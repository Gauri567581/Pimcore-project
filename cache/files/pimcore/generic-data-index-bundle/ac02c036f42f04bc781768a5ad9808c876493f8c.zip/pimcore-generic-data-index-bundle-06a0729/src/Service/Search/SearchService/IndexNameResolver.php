<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\GenericDataIndexBundle\Service\Search\SearchService;

use Pimcore\Bundle\GenericDataIndexBundle\Enum\SearchIndex\IndexName;
use Pimcore\Bundle\GenericDataIndexBundle\Exception\InvalidArgumentException;
use Pimcore\Bundle\GenericDataIndexBundle\Model\Search\Asset\AssetSearch;
use Pimcore\Bundle\GenericDataIndexBundle\Model\Search\DataObject\DataObjectSearch;
use Pimcore\Bundle\GenericDataIndexBundle\Model\Search\Document\DocumentSearch;
use Pimcore\Bundle\GenericDataIndexBundle\Model\Search\Element\ElementSearch;
use Pimcore\Bundle\GenericDataIndexBundle\Model\Search\Interfaces\SearchInterface;
use Pimcore\Bundle\GenericDataIndexBundle\Service\SearchIndex\IndexService\ElementTypeAdapter\AssetTypeAdapter;
use Pimcore\Bundle\GenericDataIndexBundle\Service\SearchIndex\IndexService\ElementTypeAdapter\DataObjectTypeAdapter;
use Pimcore\Bundle\GenericDataIndexBundle\Service\SearchIndex\IndexService\ElementTypeAdapter\DocumentTypeAdapter;
use Pimcore\Bundle\GenericDataIndexBundle\Service\SearchIndex\SearchIndexConfigServiceInterface;

/**
 * @internal
 */
final readonly class IndexNameResolver implements IndexNameResolverInterface
{
    public function __construct(
        private AssetTypeAdapter $assetTypeAdapter,
        private DataObjectTypeAdapter $dataObjectTypeAdapter,
        private DocumentTypeAdapter $documentTypeAdapter,
        private SearchIndexConfigServiceInterface $searchIndexConfigService
    ) {
    }

    public function resolveIndexName(SearchInterface $search): string
    {
        if ($search instanceof AssetSearch) {
            return $this->assetTypeAdapter->getAliasIndexName();
        }

        if ($search instanceof DataObjectSearch) {
            return $this->dataObjectTypeAdapter->getAliasIndexName(
                $search->getClassDefinition() ?? IndexName::DATA_OBJECT->value
            );
        }

        if ($search instanceof DocumentSearch) {
            return $this->documentTypeAdapter->getAliasIndexName();
        }

        if ($search instanceof ElementSearch) {
            return $this->searchIndexConfigService->getIndexName(IndexName::ELEMENT_SEARCH->value);
        }

        throw new InvalidArgumentException('Unsupported search type: ' . get_class($search));
    }
}
