<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\GenericDataIndexBundle\Service\SearchIndex\IndexQueue;

use Doctrine\DBAL\Exception;
use Exception as ThrowableException;
use Pimcore\Bundle\GenericDataIndexBundle\Enum\SearchIndex\ElementType;
use Pimcore\Bundle\GenericDataIndexBundle\Enum\SearchIndex\IndexName;
use Pimcore\Bundle\GenericDataIndexBundle\Enum\SearchIndex\IndexQueueOperation;
use Pimcore\Bundle\GenericDataIndexBundle\Exception\EnqueueElementsException;
use Pimcore\Bundle\GenericDataIndexBundle\Repository\IndexQueueRepository;
use Pimcore\Bundle\GenericDataIndexBundle\Service\Search\SearchService\RequiredByElementListServiceInterface;
use Pimcore\Bundle\GenericDataIndexBundle\Service\SearchIndex\IndexService\ElementTypeAdapter\AdapterServiceInterface;
use Pimcore\Bundle\GenericDataIndexBundle\Service\TimeServiceInterface;
use Pimcore\Model\DataObject\ClassDefinition;
use Pimcore\Model\Element\ElementInterface;
use Pimcore\Model\Element\Tag;

/**
 * @internal
 */
final readonly class EnqueueService implements EnqueueServiceInterface
{
    public function __construct(
        private IndexQueueRepository $indexQueueRepository,
        private TimeServiceInterface $timeService,
        private QueueMessagesDispatcher $queueMessagesDispatcher,
        private AdapterServiceInterface $typeAdapterService,
        private RequiredByElementListServiceInterface $requiredByElementListService
    ) {

    }

    /**
     * @throws Exception
     */
    public function enqueueByTag(Tag $tag): EnqueueService
    {
        $tagCondition = $this->indexQueueRepository->generateSelectQuery(
            'tags_assignment',
            [
                'elementId' => 'cid',
            ],
            [],
            ['ctype', IndexQueueRepository::AND_OPERATOR => 'tagid']
        );

        //assets
        $assetQuery = $this->indexQueueRepository->generateSelectQuery(
            'assets',
            [
                'elementId' => 'id',
                'elementType' => "'" . ElementType::ASSET->value . "'",
                'elementIndexName' => "'" . IndexName::ASSET->value . "'",
                'operation' => "'" . IndexQueueOperation::UPDATE->value . "'",
                'operationTime' => "'" . (string)$this->timeService->getCurrentMillisecondTimestamp() . "'",
                'dispatched' => '0',
            ],
            ['ctype' => ElementType::ASSET->value, 'tagid' => $tag->getId()],
        );
        $assetQuery->where($assetQuery->expr()->in('id', $tagCondition->getSQL()));
        $this->indexQueueRepository->enqueueBySelectQuery($assetQuery);

        //data objects
        $dataObjectQuery = $this->indexQueueRepository->generateSelectQuery(
            'objects',
            [
                'elementId' => 'id',
                'elementType' => "'" . ElementType::DATA_OBJECT->value . "'",
                'elementIndexName' => 'className',
                'operation' => "'" . IndexQueueOperation::UPDATE->value . "'",
                'operationTime' => "'" . (string)$this->timeService->getCurrentMillisecondTimestamp() . "'",
                'dispatched' => '0',
            ],
            ['ctype' => ElementType::DATA_OBJECT->value, 'tagid' => $tag->getId()],
        );
        $dataObjectQuery->where($dataObjectQuery->expr()->in('id', $tagCondition->getSQL()));
        $this->indexQueueRepository->enqueueBySelectQuery($dataObjectQuery);

        return $this;
    }

    /**
     * @throws Exception
     */
    public function enqueueByClassDefinition(ClassDefinition $classDefinition): EnqueueService
    {
        $dataObjectTableName = 'object_' . $classDefinition->getId();
        $selectQuery = $this->indexQueueRepository->generateSelectQuery(
            $dataObjectTableName,
            [
                'elementId' => 'oo_id',
                'elementType' => "'" . ElementType::DATA_OBJECT->value . "'",
                'elementIndexName' => "'" . $classDefinition->getName() . "'",
                'operation' => "'" . IndexQueueOperation::UPDATE->value . "'",
                'operationTime' => "'" . (string)$this->timeService->getCurrentMillisecondTimestamp() . "'",
                'dispatched' => '0',
            ]
        );
        $this->indexQueueRepository->enqueueBySelectQuery(
            $selectQuery
        );

        return $this;
    }

    public function enqueueDataObjectFolders(): EnqueueServiceInterface
    {
        try {
            $selectQuery = $this->indexQueueRepository->generateSelectQuery(
                'objects',
                [
                    'elementId' => 'id',
                    'elementType' => "'" . ElementType::DATA_OBJECT->value . "'",
                    'elementIndexName' => "'" . IndexName::DATA_OBJECT_FOLDER->value . "'",
                    'operation' => "'" . IndexQueueOperation::UPDATE->value . "'",
                    'operationTime' => "'" . (string)$this->timeService->getCurrentMillisecondTimestamp() . "'",
                    'dispatched' => '0',
                ],
            )->where('type = "folder"');
            $this->indexQueueRepository->enqueueBySelectQuery($selectQuery);
        } catch (Exception $e) {
            throw new EnqueueElementsException(
                $e->getMessage()
            );
        }

        return $this;
    }

    /**
     * @throws EnqueueElementsException
     */
    public function enqueueAssets(): EnqueueService
    {
        try {
            $selectQuery = $this->indexQueueRepository->generateSelectQuery(
                'assets',
                [
                    'elementId' => 'id',
                    'elementType' => "'" . ElementType::ASSET->value . "'",
                    'elementIndexName' => "'" . IndexName::ASSET->value . "'",
                    'operation' => "'" . IndexQueueOperation::UPDATE->value . "'",
                    'operationTime' => "'" . (string)$this->timeService->getCurrentMillisecondTimestamp() . "'",
                    'dispatched' => '0',
                ]
            );
            $this->indexQueueRepository->enqueueBySelectQuery($selectQuery);
        } catch (Exception $e) {
            throw new EnqueueElementsException(
                $e->getMessage()
            );
        }

        return $this;
    }

    /**
     * @throws EnqueueElementsException
     */
    public function enqueueDocuments(): EnqueueService
    {
        try {
            $selectQuery = $this->indexQueueRepository->generateSelectQuery(
                'documents',
                [
                    'elementId' => 'id',
                    'elementType' => "'" . ElementType::DOCUMENT->value . "'",
                    'elementIndexName' => "'" . IndexName::DOCUMENT->value . "'",
                    'operation' => "'" . IndexQueueOperation::UPDATE->value . "'",
                    'operationTime' => "'" . (string)$this->timeService->getCurrentMillisecondTimestamp() . "'",
                    'dispatched' => '0',
                ]
            );
            $this->indexQueueRepository->enqueueBySelectQuery($selectQuery);
        } catch (Exception $e) {
            throw new EnqueueElementsException(
                $e->getMessage()
            );
        }

        return $this;
    }

    /**
     * @throws ThrowableException
     */
    public function enqueueRelatedItems(
        ElementInterface $element,
        bool $includeElement,
        string $operation
    ): void {
        $subQuery = $this->typeAdapterService
            ->getTypeAdapter($element)
            ->getRelatedItemsOnUpdateQuery(
                element: $element,
                operation: $operation,
                operationTime: $this->timeService->getCurrentMillisecondTimestamp(),
                includeElement: $includeElement,
            );

        if ($subQuery) {
            $this->indexQueueRepository->enqueueBySelectQuery($subQuery);
        }
    }

    /**
     * @throws ThrowableException
     */
    public function enqueueDependentItems(
        ElementInterface $element,
        IndexQueueOperation $operation
    ): void {
        $dependentItems = $this->requiredByElementListService->getDependencyList($element);
        foreach (array_chunk($dependentItems, 1000) as $chunk) {
            $this->indexQueueRepository->enqueueByItemList(
                $chunk,
                $operation,
                $this->timeService->getCurrentMillisecondTimestamp()
            );
        }
    }

    public function dispatchQueueMessages(bool $synchronously = false): void
    {
        $this->queueMessagesDispatcher->dispatchQueueMessages($synchronously);
    }
}
