<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\GenericDataIndexBundle\Service\SearchIndex\IndexService\ElementTypeAdapter;

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Query\QueryBuilder;
use InvalidArgumentException;
use Pimcore\Bundle\GenericDataIndexBundle\Enum\SearchIndex\ElementType;
use Pimcore\Bundle\GenericDataIndexBundle\Enum\SearchIndex\IndexName;
use Pimcore\Bundle\GenericDataIndexBundle\Event\Asset\UpdateIndexDataEvent;
use Pimcore\Bundle\GenericDataIndexBundle\Event\UpdateIndexDataEventInterface;
use Pimcore\Bundle\GenericDataIndexBundle\Service\Serializer\Normalizer\AssetNormalizer;
use Pimcore\Model\Asset;
use Pimcore\Model\Element\ElementInterface;
use Symfony\Component\Serializer\Normalizer\NormalizerInterface;

/**
 * @internal
 */
final class AssetTypeAdapter extends AbstractElementTypeAdapter
{
    public function __construct(
        private readonly AssetNormalizer $normalizer,
        private readonly Connection $dbConnection,
    ) {
    }

    public function supports(ElementInterface $element): bool
    {
        return $element instanceof Asset;
    }

    public function getIndexNameShortByElement(ElementInterface $element): string
    {
        return $this->getIndexNameShort();
    }

    public function getIndexNameShort(mixed $context = null): string
    {
        return IndexName::ASSET->value;
    }

    public function getElementType(): string
    {
        return ElementType::ASSET->value;
    }

    public function childrenPathRewriteNeeded(ElementInterface $element): bool
    {
        return $element instanceof Asset\Folder;
    }

    public function getNormalizer(): NormalizerInterface
    {
        return $this->normalizer;
    }

    public function getUpdateIndexDataEvent(
        ElementInterface $element,
        array $customFields
    ): UpdateIndexDataEventInterface {
        if (!$element instanceof Asset) {
            throw new InvalidArgumentException('Element must be of type Asset');
        }

        return new UpdateIndexDataEvent($element, $customFields);
    }

    public function getRelatedItemsOnUpdateQuery(
        ElementInterface $element,
        string $operation,
        int $operationTime,
        bool $includeElement = false
    ): QueryBuilder {

        $selects = [
            (string)$element->getId() . ' AS elementId',
            "'" . ElementType::ASSET->value . "' AS elementType",
            "'" . IndexName::ASSET->value . "' AS elementIndexName",
            "'$operation' AS operation",
            "'$operationTime' AS operationTime",
            '0 AS dispatched',
        ];

        return $this->dbConnection->createQueryBuilder()
            ->addSelect(...$selects)
            ->from('DUAL') // just a dummy query to fit into the query builder interface
            ->setMaxResults(1);
    }
}
