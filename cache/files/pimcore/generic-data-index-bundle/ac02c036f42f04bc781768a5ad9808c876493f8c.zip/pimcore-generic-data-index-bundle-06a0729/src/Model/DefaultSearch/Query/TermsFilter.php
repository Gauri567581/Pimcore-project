<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\GenericDataIndexBundle\Model\DefaultSearch\Query;

use Pimcore\Bundle\GenericDataIndexBundle\Enum\SearchIndex\DefaultSearch\ConditionType;

final class TermsFilter extends BoolQuery implements AsSubQueryInterface
{
    public function __construct(
        private readonly string $field,
        /** @var (int|string|bool)[] */
        private readonly array $terms,
    ) {
        parent::__construct([
            ConditionType::FILTER->value => [
                'terms' => [
                    $this->field => $this->terms,
                ],
            ],
        ]);
    }

    public function getField(): string
    {
        return $this->field;
    }

    /** @return (int|string|bool)[] */
    public function getTerms(): array
    {
        return $this->terms;
    }

    public function toArrayAsSubQuery(): array
    {
        return [
            'terms' => [
                $this->field => $this->terms,
            ],
        ];
    }
}
