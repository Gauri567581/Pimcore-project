<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\GenericDataIndexBundle\Model\Search\Modifier\Filter\FieldType;

use Carbon\Carbon;
use Pimcore\Bundle\GenericDataIndexBundle\Model\Search\Modifier\SearchModifierInterface;

final readonly class DateFilter implements SearchModifierInterface
{
    private Carbon|null $startDate;

    private Carbon|null $endDate;

    private Carbon|null $onDate;

    public function __construct(
        private string $field,
        int|Carbon|null $startDate = null,
        int|Carbon|null $endDate = null,
        int|Carbon|null $onDate = null,
        private bool $roundToDay = true,
        private bool $enablePqlFieldNameResolution = true,
    ) {
        $this->startDate = is_int($startDate) ? Carbon::createFromTimestamp($startDate, date_default_timezone_get()) :
            $startDate;
        $this->endDate = is_int($endDate) ? Carbon::createFromTimestamp($endDate, date_default_timezone_get()) :
            $endDate;
        $this->onDate = is_int($onDate) ? Carbon::createFromTimestamp($onDate, date_default_timezone_get()) : $onDate;
    }

    public function getStartDate(): ?Carbon
    {
        return $this->startDate;
    }

    public function getEndDate(): ?Carbon
    {
        return $this->endDate;
    }

    public function getOnDate(): ?Carbon
    {
        return $this->onDate;
    }

    public function getField(): string
    {
        return $this->field;
    }

    public function isRoundToDay(): bool
    {
        return $this->roundToDay;
    }

    public function isPqlFieldNameResolutionEnabled(): bool
    {
        return $this->enablePqlFieldNameResolution;
    }
}
