<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\GenericDataIndexBundle;

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Exception;
use Doctrine\DBAL\Schema\Comparator;
use Doctrine\DBAL\Schema\Schema;
use Doctrine\DBAL\Schema\SchemaException;
use Pimcore;
use Pimcore\Bundle\GenericDataIndexBundle\Entity\IndexQueue;
use Pimcore\Bundle\GenericDataIndexBundle\Migrations\Version20251009110653;
use Pimcore\Bundle\InstallBundle\Profile\PostInstallCommand;
use Pimcore\Bundle\InstallBundle\Profile\PostInstallCommandsProviderInterface;
use Symfony\Component\HttpKernel\Bundle\BundleInterface;

/**
 * @internal
 */
final class Installer extends Pimcore\Extension\Bundle\Installer\SettingsStoreAwareInstaller implements PostInstallCommandsProviderInterface
{
    public function __construct(
        private readonly Connection $db,
        BundleInterface $bundle,

    ) {
        parent::__construct($bundle);
    }

    public function getPostInstallCommands(): array
    {
        return [
            new PostInstallCommand(
                command: 'generic-data-index:update:index',
                label: 'Creating search index',
                priority: 100,
                arguments: ['-r'],
            ),
        ];
    }

    public function getLastMigrationVersionClassName(): string
    {
        return Version20251009110653::class;
    }

    /**
     * @throws SchemaException|Exception
     */
    public function install(): void
    {
        $this->installBundle();
        parent::install();
    }

    /**
     * @throws Exception
     */
    public function uninstall(): void
    {
        $this->uninstallBundle();
        parent::uninstall();
    }

    /**
     * @throws SchemaException|Exception
     */
    private function installBundle(): void
    {
        $currentSchema = $this->db->createSchemaManager()->introspectSchema();
        $this->installIndexQueueTable($currentSchema);
        $this->executeDiffSql($currentSchema);
    }

    /**
     * @throws Exception
     */
    private function uninstallBundle(): void
    {
        $schemaManager = $this->db->createSchemaManager();
        $currentSchema = $schemaManager->introspectSchema();
        $this->executeDiffSql($currentSchema);
        $this->removeIndexQueueTable($currentSchema);
    }

    /**
     * @throws SchemaException
     */
    private function installIndexQueueTable(Schema $schema): void
    {
        if (!$schema->hasTable(IndexQueue::TABLE)) {
            $queueTable = $schema->createTable(IndexQueue::TABLE);
            $queueTable->addColumn('id', 'bigint', ['autoincrement' => true]);
            $queueTable->addColumn('elementId', 'integer', ['notnull' => true, 'unsigned' => true]);
            $queueTable->addColumn('elementType', 'string', ['notnull' => true, 'length' => 20]);
            $queueTable->addColumn('elementIndexName', 'string', ['notnull' => true, 'length' => 255]);
            $queueTable->addColumn('operation', 'string', ['notnull' => true, 'length' => 20]);
            $queueTable->addColumn('operationTime', 'bigint', ['notnull' => true, 'unsigned' => true]);
            $queueTable->addColumn('dispatched', 'bigint', [
                'notnull' => true,
                'unsigned' => true,
                'default' => 0,
            ]);

            $queueTable->setPrimaryKey(['id']);
            $queueTable->addUniqueIndex(['elementId', 'elementType'], IndexQueue::TABLE . '_element_id_type');
            $queueTable->addIndex(['dispatched'], IndexQueue::TABLE . '_dispatched');
            $queueTable->addIndex(['operationTime'], IndexQueue::TABLE . '_operation_time');
        }
    }

    /**
     * @throws Exception
     */
    private function removeIndexQueueTable(Schema $schema): void
    {
        if ($schema->hasTable(IndexQueue::TABLE)) {
            $this->db->executeStatement('DROP TABLE ' . IndexQueue::TABLE);
        }
    }

    /**
     * @throws Exception
     */
    private function executeDiffSql(Schema $newSchema): void
    {
        $currentSchema = $this->db->createSchemaManager()->introspectSchema();
        $schemaComparator = new Comparator($this->db->getDatabasePlatform());
        $schemaDiff = $schemaComparator->compareSchemas($currentSchema, $newSchema);
        $dbPlatform = $this->db->getDatabasePlatform();

        $sqlStatements = $dbPlatform->getAlterSchemaSQL($schemaDiff);

        if (!empty($sqlStatements)) {
            $this->db->executeStatement(implode(';', $sqlStatements));
        }
    }
}
