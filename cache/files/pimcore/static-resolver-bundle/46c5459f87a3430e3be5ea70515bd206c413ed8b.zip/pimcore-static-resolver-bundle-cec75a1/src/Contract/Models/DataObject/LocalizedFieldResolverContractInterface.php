<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\StaticResolverBundle\Contract\Models\DataObject;

interface LocalizedFieldResolverContractInterface
{
    public function setGetFallbackValues(bool $getFallbackValues): void;

    public function getGetFallbackValues(): bool;

    public function isStrictMode(): bool;

    public function setStrictMode(bool $strictMode): void;

    public function doGetFallbackValues(): bool;

    public function locateDaoClass(string $modelClass): ?string;
}
